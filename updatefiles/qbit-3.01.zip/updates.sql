DROP TABLE IF EXISTS `maps2`;
CREATE TABLE `maps2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lq` text NOT NULL,
  `container_type` varchar(255) NOT NULL,
  `container_id` int(11) NOT NULL,
  `resource_type` varchar(255) NOT NULL,
  `resource_name` varchar(255) NOT NULL,
  `resource_id` int(11) NOT NULL DEFAULT '0',
  `action` varchar(255) NOT NULL,
  `design` varchar(255) NOT NULL,
  `material_design` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13;


INSERT INTO `maps2` VALUES ('2', 'module type=contents name=Beynelxalq_elaqeler action=getContent', 'pages', '6', 'contents', 'Beynelxalq_elaqeler', '0', 'getContent', '', '');
INSERT INTO `maps2` VALUES ('11', 'module type=pages action=getMenu design=main_menu_design_2 group=main_menu', 'layouts', '1', 'pages', '', '0', 'getMenu', 'main_menu_design_2', '');
INSERT INTO `maps2` VALUES ('12', 'container name=central_container', 'layouts', '1', '', 'central_container', '0', '', '', '');
